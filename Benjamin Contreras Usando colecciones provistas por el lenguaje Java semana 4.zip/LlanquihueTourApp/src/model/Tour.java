package model;

/**
 * Representa un tour ofrecido por la agencia Llanquihue Tour.
 * Guarda el nombre, el tipo, el precio y la duracion en horas.
 *
 * @author Benjamin
 * @version 1.0
 */
public class Tour {

    private String nombre;
    private String tipo;
    private int precio;
    private int duracion;

    /**
     * Crea un tour con todos sus datos.
     *
     * @param nombre   nombre del tour
     * @param tipo     tipo de tour (gastronómico, lacustre, aventura, cultural)
     * @param precio   precio del tour en pesos chilenos
     * @param duracion duracion del tour en horas
     */
    public Tour(String nombre, String tipo, int precio, int duracion) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.duracion = duracion;
    }

    /**
     * Obtiene el nombre del tour.
     *
     * @return nombre del tour
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Cambia el nombre del tour.
     *
     * @param nombre nuevo nombre del tour
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el tipo del tour.
     *
     * @return tipo del tour
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Cambia el tipo del tour.
     *
     * @param tipo nuevo tipo del tour
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * Obtiene el precio del tour.
     *
     * @return precio del tour en pesos chilenos
     */
    public int getPrecio() {
        return precio;
    }

    /**
     * Cambia el precio del tour.
     *
     * @param precio nuevo precio del tour
     */
    public void setPrecio(int precio) {
        this.precio = precio;
    }

    /**
     * Obtiene la duracion del tour.
     *
     * @return duracion del tour en horas
     */
    public int getDuracion() {
        return duracion;
    }

    /**
     * Cambia la duracion del tour.
     *
     * @param duracion nueva duracion del tour en horas
     */
    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    /**
     * Devuelve los datos del tour como texto.
     *
     * @return texto con el nombre, tipo, precio y duracion del tour
     */
    @Override
    public String toString() {
        return "Tour{" +
                "nombre='" + nombre + '\'' +
                ", tipo='" + tipo + '\'' +
                ", precio=" + precio +
                ", duracion=" + duracion + " horas" +
                '}';
    }
}
