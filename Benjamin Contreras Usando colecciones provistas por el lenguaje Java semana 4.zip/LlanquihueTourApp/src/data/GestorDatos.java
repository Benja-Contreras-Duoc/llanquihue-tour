package data;

import model.Tour;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Se encarga de leer los datos de los tours desde un archivo de texto
 * y de convertirlos en objetos de tipo Tour.
 *
 * @author Benjamin
 * @version 1.0
 */
public class GestorDatos {

    /**
     * Lee un archivo .txt linea por linea y crea un Tour por cada linea valida.
     * Cada linea debe tener el formato nombre;tipo;precio;duracion.
     * Las lineas vacias o con formato incorrecto se ignoran.
     *
     * @param rutaArchivo ruta del archivo de texto con los tours
     * @return lista con los tours leidos desde el archivo
     */
    public ArrayList<Tour> cargarTours(String rutaArchivo) {
        ArrayList<Tour> tours = new ArrayList<>();

        try (BufferedReader lector = new BufferedReader(new FileReader(rutaArchivo, StandardCharsets.UTF_8))) {
            String linea;

            while ((linea = lector.readLine()) != null) {
                if (linea.trim().isEmpty()) {
                    continue;
                }

                String[] datos = linea.split(";");

                if (datos.length != 4) {
                    System.out.println("Linea con formato incorrecto: " + linea);
                    continue;
                }

                try {
                    String nombre = datos[0];
                    String tipo = datos[1];
                    int precio = Integer.parseInt(datos[2]);
                    int duracion = Integer.parseInt(datos[3]);

                    Tour tour = new Tour(nombre, tipo, precio, duracion);
                    tours.add(tour);
                } catch (NumberFormatException e) {
                    System.out.println("Error en los numeros de la linea: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer el archivo: " + e.getMessage());
        }

        return tours;
    }
}
