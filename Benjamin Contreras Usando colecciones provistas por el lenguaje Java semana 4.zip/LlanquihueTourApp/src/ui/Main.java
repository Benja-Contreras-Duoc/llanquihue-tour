package ui;

import data.GestorDatos;
import model.Tour;

import java.util.ArrayList;

/**
 * Clase principal del programa Llanquihue Tour.
 * Carga los tours desde el archivo, los muestra todos y aplica filtros.
 *
 * @author Benjamin
 * @version 1.0
 */
public class Main {

    /**
     * Metodo principal. Carga los tours, los recorre y muestra los resultados
     * de dos filtros: tipo gastronómico y precio menor a 30000.
     *
     * @param args argumentos de la linea de comandos (no se usan)
     */
    public static void main(String[] args) {
        GestorDatos gestor = new GestorDatos();
        ArrayList<Tour> tours = gestor.cargarTours("resources/tours.txt");

        System.out.println("===== LLANQUIHUE TOUR =====");
        System.out.println("Total de tours cargados: " + tours.size());
        System.out.println();

        System.out.println("--- Todos los tours ---");
        for (Tour tour : tours) {
            System.out.println(tour);
        }

        System.out.println();
        System.out.println("--- Tours de tipo gastronómico ---");
        boolean encontrado = false;
        for (Tour tour : tours) {
            if (tour.getTipo().equals("gastronómico")) {
                System.out.println(tour);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No hay tours de ese tipo.");
        }

        System.out.println();
        System.out.println("--- Tours con precio menor a 30000 ---");
        encontrado = false;
        for (Tour tour : tours) {
            if (tour.getPrecio() < 30000) {
                System.out.println(tour);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No hay tours con ese precio.");
        }
    }
}
