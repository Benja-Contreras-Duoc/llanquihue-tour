# llanquihue-tour

Proyecto de la semana 4 de Desarrollo Orientado a Objetos I.

## Descripción

Programa en Java para la agencia Llanquihue Tour. Lee los tours desde un archivo de texto, crea objetos y los guarda en un ArrayList. Luego muestra todos los tours y aplica filtros por tipo y por precio.

## Estructura de carpetas

```
LlanquihueTourApp/
├── src/
│   ├── model/
│   │   └── Tour.java
│   ├── data/
│   │   └── GestorDatos.java
│   └── ui/
│       └── Main.java
├── resources/
│   └── tours.txt
└── README.md
```

## Formato del archivo tours.txt

Cada línea tiene este formato, separado por punto y coma y sin espacios entre campos:

```
nombre;tipo;precio;duracion
```

## Cómo ejecutar la clase Main

Con IntelliJ IDEA:

1. Abrir la carpeta LlanquihueTourApp como proyecto.
2. Marcar la carpeta `src` como Sources Root.
3. Ejecutar la clase `Main` del paquete `ui`.

Con la terminal, desde la carpeta raíz del proyecto:

```
javac -encoding UTF-8 -d out src/model/Tour.java src/data/GestorDatos.java src/ui/Main.java
java -Dfile.encoding=UTF-8 -cp out ui.Main
```
